    # Documentatie : D10
    # Omschrijving : Deze code vraagt de grootte van het bestand
file_size = os.path.getsize(file_path)
