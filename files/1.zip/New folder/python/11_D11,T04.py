    # Taak         : T04 - Schrijf een if/elif/else conditie die voldoet aan de omschrijving in D11.
    # Documentatie : D11
    # Omschrijving : Indien file_size kleiner of gelijk is aan 102400 bytes verhoog dan small_files_count met +1
    #                Indien file_size groter is dan 102400 en kleiner dan 204800 bytes verhoog dan medium_files_count met +1
    #                Alle andere bestandsgroottes verhoog large_files_count  met +1
    
    # Code van taak T04 hier

if file_size <= 102400:                  #kleiner of gelijk is aan 102400 bytes
    small_files_count + 1                #small_files_count + 1

elif 102400 < file_size < 204800:        #Tussen 102400-204800 bytes   
    medium_files_count + 1               #medium_files_count + 1   

else:
    large_files_count + 1                #De situatie van de rest zijn gewoon large files

    # Einde T04
