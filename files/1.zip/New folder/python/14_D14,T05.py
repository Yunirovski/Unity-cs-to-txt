# Taak         : T05 - Geef het totaal aantal ongeldige hashes weer uit de variabele invalid_hash_count
# Documentatie : D14
# Omschrijving : Weergeven van de totalen zoals ongeldige hashes en verschillende bestandsgroottes.

# Code van taak T05 hier
print("Totaal ongeldige hashes                                     :", invalid_hash_count)
print("Totaal gelijk of kleiner dan 100 kilobytes                  :", small_files_coun)
print("Totaal groter dan 100 kilobytes en kleiner dan 200 kilobytes:", medium_files_count)
print("Totaal gelijk of groter dan 200 kilobytes                   :", large_files_count)



# Einde T05
