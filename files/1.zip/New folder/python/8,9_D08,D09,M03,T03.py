# Documentatie : D08
# Omschrijving : Deze loop controleert alle bestand in het manifest door het path en hash te vergelijken.
for obj in objects:
    file_path = obj["Path"]
    file_hash = calculate_hash(file_path)
    # D09 Controleren of de file_hash gelijk is met de hash in het manifest bestand
    if obj["Hash"] != file_hash:
        M03 = "Ongeldige hash gevonden! : bestand.ext" # melding naar gebruiker
        print('{}'.format(M03)) #M03

        # Taak         :  T03 - Schrijf een passende melding naar het logboek met de functie add_to_log("message")
        #                       Geef duidelijk aan om welk bestand het gaat zoals in file_path.
        
        # Code van taak T03 hier
    def add_to_log(message):
            with open("log.txt", "a") as log_file:
                 log_file
add_to_log(f"De hashwaarde van het bestand komt niet overeen, bestand is gewijzigd")            
# Einde T03

invalid_hash_count += 1