# Documentatie : D06 
# Omschrijving : Deze code opent het manifest bestand (een JSON-bestand) en laadt de inhoud in het geheugen.
with open(manifest_file, "r") as f:
    objects = json.load(f)
