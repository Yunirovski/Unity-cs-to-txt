# Taak         : T02 - Schrijf een while-loop die continu om input vraagt of het script mag worden uitgevoerd.
#                      Als de gebruiker geen geldige invoer (j/n of ja/nee) geeft, wordt de melding "Ongeldige invoer" weergegeven.
#                      Als de gebruiker "j" of "ja" invoert, wordt het script voortgezet met de uitvoer.
#                      Verwijder indien nodig de comments (#) uit de code van T02.
# Documentatie : D02 
# Omschrijving : Vragen of het script mag worden uitgevoerd.

# Start Code van taak T02 hier

while True: #loop
    uitvoer = input("Mag dit script worden uitgevoerd? : Doorgaan ja/nee?").lower()
    if uitvoer in {"j", "ja"}:
        break
    elif uitvoer in {"n", "nee"}:
        exit()
    else:
        print("Ongeldige invoer")

# Einde T02
