# Documentatie : D05
# Omschrijving : Deze code controleert of het manifestbestand bestaat. Als het bestand niet bestaat, wordt een melding (M02) naar de gebruiker weergegeven en wordt het script beëindigd.
if not os.path.exists(manifest_file):
    M02 = "Manifest.json is niet aanwezig." # Melding naar gebruiker
    print('{}'.format(M02)) # Weergave van de melding (M02)
    exit()
