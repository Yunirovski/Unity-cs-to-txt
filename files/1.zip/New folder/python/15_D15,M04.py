# Documentatie : D15
# Omschrijving : Melding naar gebruiker dat het script klaar is met de uitvoer.
M04 = "--- Einde Integriteitscontrole ---" # Klaar uitvoer melding 
print('{}'.format(M04)) #M04