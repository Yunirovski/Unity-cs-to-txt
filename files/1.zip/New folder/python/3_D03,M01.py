# Documentatie : D03
# Omschrijving : Controleer of de opgegeven map (folder) bestaat. Als de map niet bestaat, wordt een melding (M01) naar de gebruiker weergegeven en wordt het script beëindigd.
if not os.path.exists(folder):
    M01 = "De map Files bestaat niet." # Melding naar gebruiker
    print('{}'.format(M01)) # Weergave van de melding (M01)
    exit()
