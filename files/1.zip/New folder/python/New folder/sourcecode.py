# Naam         : Integriteit.py
# Versie       : 1.0
# Omschrijving : Dit python-script voert integriteitscontroles uit op een verzameling bestanden
#                door hun hashwaarden en groottes te vergelijken met een vooraf gedefinieerd manifest.
#                Mogelijke wijzigingen of afwijkingen in het manifest moeten altijd worden gelogd
#                met de functie add_to_log("message")


# Libraries - code niet wijzigen

import hashlib
import json
import os

# Einde Libraries

# Functions - code niet wijzigen

def add_to_log(message):
    log_file = "log.txt"
    try:
        with open(log_file, "a") as f:
            f.write(f"{message}\n")
    except Exception as e:
        print(f"Error writing data to {log_file}.")
        exit()

def calculate_hash(file_path):
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        while True:
            data = f.read(65536)
            if not data:
                break
            sha256.update(data)
    return sha256.hexdigest().upper()

# Einde Functions

###########################################################################
#                           Initalisatie                                  #
###########################################################################

# Taak         : T01 - Maak een variable manifest_file met de stringvalue manifest.json
# Documentatie : D01 
# Omschrijving : <invullen>

# Code van taak T01 hier

# Einde T01

folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Files")

invalid_hash_count = 0
small_files_count = 0
medium_files_count = 0
large_files_count = 0

# Taak         : T02 - Schrijf een while-loop die continu om input vraagt of het script mag worden uitgevoerd.
#                      Als de gebruiker geen geldige invoer (j/n of ja/nee) geeft, wordt de melding "Ongeldige invoer" weergegeven.
#                      Als de gebruiker "j" of "ja" invoert, wordt het script voortgezet met de uitvoer.
#                      Verwijder indien nodig de comments (#) uit de code van T02.
# Documentatie : D02 
# Omschrijving : Vragen of het script mag worden uitgevoerd.

# Start Code van taak T02 hier

#uitvoer = input("Mag dit script worden uitgevoerd? : Doorgaan j/n?").lower()
#if uitvoer in {"j", "ja"}:
    # break
#elif uitvoer in {"n", "nee"}:
    # exit()
#else:
#    print("Ongeldige invoer")
# Einde T02

# Documentatie : D03 
# Omschrijving : <invullen>
if not os.path.exists(folder):
    M01 = "" # melding naar gebruiker
    print('{}'.format(M01)) #M01
    exit()

# Documentatie : D04 
# Omschrijving : Het veranderen van de uitvoer directory (chdir=change directory) 
os.chdir(folder)

# Documentatie : D05 
# Omschrijving : Controleren of het manifest bestand bestaat
if not os.path.exists(manifest_file):
    M02 = "" # melding naar gebruiker
    print('{}'.format(M02)) #M02
    exit()

# Documentatie : D06 
# Omschrijving : <invullen>
with open(manifest_file, "r") as f:
    objects = json.load(f)

###########################################################################
#                               Uitvoer                                   #
###########################################################################

# Documentatie : D07 
# Omschrijving : Starten van het script met een passende melding
print("----------------- Start Integriteitscontrole script ----------------")

# Documentatie : D08 
# Omschrijving : <invullen>
for obj in objects:
    file_path = obj["Path"]
    file_hash = calculate_hash(file_path)
    # D09 Controleren of de file_hash gelijk is met de hash in het manifest bestand
    if obj["Hash"] != file_hash:
        M03 = "" # melding naar gebruiker
        print('{}'.format(M03)) #M03

        # Taak         :  T03 - Schrijf een passende melding naar het logboek met de functie add_to_log("message")
        #                       Geef duidelijk aan om welk bestand het gaat zoals in file_path.
        
        # Code van taak T03 hier

        # Einde T03

        invalid_hash_count += 1

    # Documentatie : D10
    # Omschrijving : De bestandsgrootte opvragen 
    file_size = os.path.getsize(file_path)
    
    # Taak         : T04 - Schrijf een if/elif/else conditie die voldoet aan de omschrijving in D11.
    # Documentatie : D11
    # Omschrijving : Indien file_size kleiner of gelijk is aan 102400 bytes verhoog dan small_files_count met +1
    #                Indien file_size groter is dan 102400 en kleiner dan 204800 bytes verhoog dan medium_files_count met +1
    #                Alle andere bestandsgroottes verhoog large_files_count  met +1
    
    # Code van taak T04 hier



    
    
    
    # Einde T04
    
   
###########################################################################
#                               Afronding                                 #
###########################################################################

# Taak         : T05 - Geef het totaal aantal ongeldige hashes weer uit de variabele invalid_hash_count
# Documentatie : D14
# Omschrijving : Weergeven van de totalen zoals ongeldige hashes en verschillende bestandsgroottes.

# Code van taak T05 hier

# Einde T05

print(f"Totaal kleiner dan 100 kilobytes                            : {small_files_count}")
print(f"Totaal groter dan 100 kilobytes en kleiner dan 200 kilobytes: {medium_files_count}")
print(f"Totaal groter dan 200 kilobytes                             : {large_files_count}")

# Documentatie : D15
# Omschrijving : Melding naar gebruiker dat het script klaar is met de uitvoer.
M04 = "" # melding naar gebruiker
print('{}'.format(M04)) #M04