# Documentatie : D07
# Omschrijving : Starten van het script met een passende melding
print("---Start Integriteitscontrole ---")
