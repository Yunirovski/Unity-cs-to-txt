###########################################################################
#                           Initalisatie                                  #
###########################################################################

# Taak         : T01 - Maak een variable manifest_file met de stringvalue manifest.json
# Documentatie : D01 
# Omschrijving : <variable voor manifest file>

# Code van taak T01 hier
manifest_file = "manifest.json"#variable voor manifest file
# Einde T01

folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Files")

invalid_hash_count = 0
small_files_count = 0
medium_files_count = 0
large_files_count = 0


manifest_file = "manifest.json"

# Einde T01
