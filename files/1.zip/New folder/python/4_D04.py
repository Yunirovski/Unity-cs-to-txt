# Documentatie : D04
# Omschrijving : Deze regel code verandert de mapnaam als "folder".
os.chdir(folder)
